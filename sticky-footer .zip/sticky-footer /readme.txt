=== Sticky Footer ===
Contributors: Hareendranath.P
Requires at least: 3.0
Stable tag: 1.0

This is a wordpress plugin that created a sticky footer footer to all pages

== Description ==

This is a wordpress plugin that created a sticky footer in the bottom of the screen and the properties of the footer can be controlled from the admin side and text can be added to it.

== Installation ==

The quickest method for installing the importer is:

1.Click on appearance->plugin->add new plugin 
2.Upload the zip file
3.click on activate plugin
4.for settings page goto settings->sticky-footer 


